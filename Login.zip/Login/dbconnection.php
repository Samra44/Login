<?php

$conn = mysqli_connect("localhost", "root","", "logindb");
if(!$conn){
    echo "Connection Failed";
}




?>